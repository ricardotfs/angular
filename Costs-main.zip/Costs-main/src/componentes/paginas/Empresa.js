function Empresa() {
    return ( 
        <div>
            <h1>Empresa</h1>
        </div>
     );
}

export default Empresa;