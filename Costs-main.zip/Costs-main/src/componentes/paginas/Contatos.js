function Contatos() {
    return ( 
        <div>
            <h1>Contatos</h1>
        </div>
     );
}
export default Contatos;